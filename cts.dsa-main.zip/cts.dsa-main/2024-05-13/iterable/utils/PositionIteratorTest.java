package com.cts.dsa.iterable.utils;

public class PositionIteratorTest {
	public static void main(String[] args) {
		SinglyLinkedPositionalList<String> names = new SinglyLinkedPositionalList<String>();
		names.addFirst("Dilip");
		names.addFirst("Bharath");
		names.addLast("Rajesh");
		names.addLast("Nithin");
		
		Iterator<Position<String>> iterator = new PositionIterator<String>(names);
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}