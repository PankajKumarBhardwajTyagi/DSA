package com.cts.dsa.iterable.utils;

import java.util.NoSuchElementException;

public class PositionIterator<E> implements Iterator<Position<E>>{
	private SinglyLinkedPositionalList<E> data;
	private Position<E> cursor = null;
	private Position<E> recent = null;
	
	public PositionIterator(SinglyLinkedPositionalList data) {
		this.data = data;
		cursor = data.first();
	}

	@Override public boolean hasNext() { return cursor != null; }

	@Override public Position<E> next() throws NoSuchElementException {
		if(cursor == null) throw new NoSuchElementException("no element left");
		recent = cursor;
		cursor = data.after(cursor);
		return recent;
	}
}