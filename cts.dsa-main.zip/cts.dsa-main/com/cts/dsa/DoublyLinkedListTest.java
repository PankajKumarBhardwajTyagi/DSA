package com.cts.dsa;

import com.cts.dsa.util.Deque;
import com.cts.dsa.util.DoublyLinkedList;

public class DoublyLinkedListTest {
	public static void main(String[] args) {
		Deque<String> names = new DoublyLinkedList<String>();
		
		System.out.println(names);
		System.out.println();
		
		names.addFirst("Dilip");
		System.out.println(names);
		System.out.println();

		names.addFirst("Kiran");
		System.out.println(names);
		System.out.println();

		names.addLast("Bharath");
		System.out.println(names);
		System.out.println();
		
		System.out.println("Removing First: " + names.removeFirst());
		System.out.println(names);
		System.out.println();

		System.out.println("Removing Last: " + names.removeLast());
		System.out.println(names);
		System.out.println();
	}
}