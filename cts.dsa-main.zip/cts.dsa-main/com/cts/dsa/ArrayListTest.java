package com.cts.dsa;

import com.cts.dsa.util.ArrayList;
import com.cts.dsa.util.List;

public class ArrayListTest {
	public static void main(String[] args) {
		try {
			List<String> names = new ArrayList<String>();
			names.add(0, "Dilip");
			System.out.println(names);
			names.add(1, "Mahesh");
			System.out.println(names);
			names.add(2, "Santhosh");
			System.out.println(names);
			names.add(1, "Bharath");
			System.out.println(names);
			names.add(4, "Kiran");
			System.out.println(names);
			names.add(5, "Ashok");
			System.out.println(names);
			names.add(6, "Raj");
			System.out.println(names);
			names.add(7, "Rahul");
			System.out.println(names);
//			names.add(5, "Jay");
//			System.out.println(names);
//			names.add(-1, "Kiran");
//			System.out.println(names);
			System.out.println("Name at Position 3: " + names.get(3));
//			System.out.println("Name at Position 9: " + names.get(9));
			System.out.println("Modify Name at 5: " + names.set(5, "Sandeep"));
			System.out.println(names);
			System.out.println("Removing Name at 3: " + names.remove(3));
			System.out.println(names);
			System.out.println("Adding at the end of the list: " + names.add("Abcd"));
			System.out.println(names);
			System.out.println("Adding at the end of the list: " + names.add("Xyz"));
			System.out.println(names);			
		} catch(IndexOutOfBoundsException ioobe) {
			System.err.println(ioobe.getMessage());
		} catch(RuntimeException re) {
			System.err.println(re.getMessage());
		}
	}
}