package com.cts.dsa.util;

public class DoublyLinkedList<E> implements Deque<E> {
	private Node<E> head;
	private Node<E> tail;
	private int size = 0;
	
	public DoublyLinkedList() {
		head = new Node<E>(null, null, null);
		tail = new Node<E>(head, null, null);
		head.setNext(tail);
	}
	
	@Override public int size() { return size; }

	@Override public boolean isEmpty() { return size == 0; }

	@Override public E first() { 
		if(isEmpty()) throw new RuntimeException("List is Empty");
		return head.getElement();
	}

	@Override public E last() {
		if(isEmpty()) throw new RuntimeException("List is Empty");
		return tail.getElement();
	}

	@Override public void addFirst(E element) { addBetween(head, element, head.getNext()); }

	@Override public void addLast(E element) { addBetween(tail.getPrevious(), element, tail); }

	private void addBetween(Node<E> before, E element, Node<E> after) {
		Node<E> newNode = new Node<E>(before, element, after);
		if(before != null) before.setNext(newNode);
		if(after != null) after.setPrevious(newNode);
		++size;
	}
	
	@Override public E removeFirst() {
		if(isEmpty()) throw new RuntimeException("List is Empty");
		return remove(head.getNext());
	}

	@Override public E removeLast() {
		if(isEmpty()) throw new RuntimeException("List is Empty");
		return remove(tail.getPrevious());
	}
	
	private E remove(Node<E> node) {
		Node<E> before = node.getPrevious();
		Node<E> after = node.getNext();
		before.setNext(after);
		after.setPrevious(before);
		--size;
		return node.getElement();
	}

	@Override public String toString() {
		return "DoublyLinkedList [head=" + head + ", tail=" + tail + ", size=" + size + "]";
	}
}