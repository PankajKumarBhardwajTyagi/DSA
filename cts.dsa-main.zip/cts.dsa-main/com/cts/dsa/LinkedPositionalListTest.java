package com.cts.dsa;

import com.cts.dsa.util.LinkedPositionalList;
import com.cts.dsa.util.PositionalList;

public class LinkedPositionalListTest {
	public static void main(String[] args) {
		PositionalList<String> list = new LinkedPositionalList<String>();
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Dilip at First Position: " + list.addFirst("Dilip"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Rahul at Last Position: " + list.addLast("Rahul"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Raj at First Position: " + list.addFirst("Raj"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Raj at First Position: " + list.addFirst("Kiran"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Raj at First Position: " + list.addFirst("Bharath"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Data at First Position: " + list.first());
		System.out.println("Data at Last Position: " + list.last());
		System.out.println();
		
		System.out.println("Adding Kishore Before Dilip: " + list.addBefore("Dilip", "Kishore"));
		System.out.println(list);
		System.out.println();
		
		System.out.println("Adding Pankaj Before Kishore: " + list.addAfter("Kishore", "Pankaj"));
		System.out.println(list);
		System.out.println();
	}
}