package exceptions;

public class NoPlayersExist extends Exception {
	public NoPlayersExist(String message) {
		super(message);
	}
}