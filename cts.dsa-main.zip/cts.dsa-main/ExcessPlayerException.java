package exceptions;

public class ExcessPlayerException extends Exception {
	public ExcessPlayerException(String message) {
		super(message);
	}
}